# 智投简历 - 本地Agent投递指南

> **重大更新**: 现在使用账号密码登录，无需Token！操作更简单，只需2步即可开始投递。

---

## 目录

1. [什么是本地Agent](#什么是本地agent)
2. [为什么使用本地Agent](#为什么使用本地agent)
3. [系统要求](#系统要求)
4. [快速开始（5分钟上手）](#快速开始5分钟上手)
5. [使用方法](#使用方法)
6. [常见问题FAQ](#常见问题faq)
7. [故障排除](#故障排除)

---

## 什么是本地Agent

本地Agent是一个运行在您电脑上的Python程序，它的作用是：

1. **作为您电脑上的"机器人"** - 自动操作浏览器
2. **与服务器保持通信** - 接收投递任务指令
3. **执行实际投递** - 在您本地的浏览器中完成Boss直聘的投递操作

### 工作流程

```
您的电脑 (本地Agent + 浏览器) ←→ 智投简历服务器 ←→ Boss直聘
                ↑
          使用您的本地IP
```

---

## 为什么使用本地Agent

### 核心优势

| 对比项 | 服务器投递 | 本地Agent |
|--------|-----------|-----------|
| IP地址 | 云服务器IP（多人共用） | 您的家庭/办公IP（独享） |
| 浏览器指纹 | 服务器统一 | 您本地Chrome的真实指纹 |
| 风控风险 | **高** | **极低** |

本地Agent让投递请求来自您的家庭或办公网络，从Boss直聘的角度看，就像您在正常浏览网站。

---

## 系统要求

### 软件要求
- **Python 3.8+**
  - Windows: [下载地址](https://www.python.org/downloads/)
  - Mac/Linux: 通常已预装

### 硬件要求
- 内存: 4GB以上
- 网络: 稳定联网

---

## 快速开始（5分钟上手）

### 第一步：下载并解压Agent程序

从网站下载 `local-agent.zip`，解压到任意目录。

解压后的文件：
```
local-agent/
├── boss_local_agent.py    # 主程序
├── requirements.txt       # Python依赖
└── README.md              # 本文档
```

### 第二步：安装依赖（首次使用）

打开命令行/终端，进入解压目录：

**Windows**:
```cmd
cd C:\path\to\local-agent
pip install -r requirements.txt
playwright install chromium
```

**Mac/Linux**:
```bash
cd /path/to/local-agent
pip3 install -r requirements.txt
python3 -m playwright install chromium
```

> 这一步只需要执行一次

### 第三步：启动Agent

**Windows**:
```cmd
python boss_local_agent.py
```

**Mac/Linux**:
```bash
python3 boss_local_agent.py
```

程序会提示您输入智投简历的账号和密码：
```
==================================================
欢迎使用 Boss直聘本地Agent
请输入您的智投简历账号
==================================================

邮箱: your@email.com
密码: ********
```

### 第四步：登录Boss直聘

登录成功后，Agent会自动打开浏览器并导航到Boss直聘：
- 如果您之前登录过Boss直聘，会自动恢复登录状态
- 如果未登录，请在浏览器中扫码登录

### 第五步：开始投递

1. 回到智投简历网站
2. 进入Dashboard页面
3. 点击「开始投递」按钮
4. Agent会自动执行投递操作

---

## 使用方法

### 命令行参数

```bash
python boss_local_agent.py [参数]

可选参数:
  --email, -e EMAIL       登录邮箱（不提供则交互式输入）
  --password, -p PASSWORD 登录密码（不提供则交互式输入）
  --save                  保存登录信息（下次自动登录）
  --headless              无头模式（不显示浏览器窗口）
  --log-level LEVEL       日志级别 (DEBUG/INFO/WARNING/ERROR)
```

### 使用示例

```bash
# 交互式登录（推荐首次使用）
python boss_local_agent.py

# 命令行直接登录
python boss_local_agent.py -e your@email.com -p your_password

# 保存登录信息，下次自动登录
python boss_local_agent.py --save

# 无头模式（后台运行，不显示浏览器）
python boss_local_agent.py --headless

# 详细日志模式（排查问题时使用）
python boss_local_agent.py --log-level DEBUG
```

### 保存登录信息

首次登录时，程序会询问是否保存登录信息：
```
是否保存登录信息？下次自动登录 (y/N): y
✅ 登录信息已保存到 agent_config.json
```

下次启动时会自动检测并使用已保存的账号：
```
检测到已保存的账号: your@email.com
是否使用已保存的账号登录？(Y/n):
```

### 有头模式 vs 无头模式

| 特性 | 有头模式（默认） | 无头模式 |
|------|-----------------|---------|
| 浏览器窗口 | 显示，可以看到操作 | 不显示 |
| 遇到验证码 | 可以手动处理 | 无法处理 |
| 首次登录 | 方便扫码登录Boss | 需要先用有头模式登录 |

**建议**: 首次使用必须用有头模式完成Boss直聘登录。

### 停止Agent

- **方法1**: 在终端按 `Ctrl+C`
- **方法2**: 关闭终端窗口

---

## 常见问题FAQ

### Q1: 需要Token吗？

**A**: 不需要！现在使用智投简历的账号密码直接登录，更加简单方便。

### Q2: 登录信息安全吗？

**A**: 是的。
- 登录信息只保存在您本地电脑的 `agent_config.json` 文件中
- 所有通信都是加密的（HTTPS/WSS）
- 服务器只验证身份，不存储您的密码

### Q3: 电脑必须一直开着吗？

**A**: 只有在投递时需要开着。投递完成后可以关闭Agent。

### Q4: 可以在多台电脑使用吗？

**A**: 可以，但同时只能有一个Agent在线。新的Agent连接会自动踢掉旧的。

### Q5: 首次使用需要登录Boss直聘吗？

**A**: 是的。首次启动Agent时，浏览器会打开Boss直聘，您需要用手机扫码登录。登录后Cookie会被保存，后续使用无需再次登录。

### Q6: 投递时遇到验证码怎么办？

**A**:
- **有头模式**: 验证码会显示在浏览器中，您可以手动完成
- **无头模式**: 无法处理验证码，建议切换到有头模式

### Q7: 会不会被Boss直聘封号？

**A**: 风险极低。
- 从Boss直聘角度看，就像您在正常使用浏览器
- 使用的是您自己的IP和浏览器
- Agent有模拟人类行为的功能（随机延迟、打字模拟等）

---

## 故障排除

### 问题1: "登录失败: 账号或密码错误"

**解决方法**:
1. 确认使用的是智投简历网站的账号密码
2. 在网站上测试登录是否正常
3. 如果忘记密码，在网站上重置密码

### 问题2: "连接失败，等待重连..."

**可能原因**:
- 网络问题
- 服务器暂时不可用
- 登录信息无效

**解决方法**:
```bash
# 1. 检查网络
ping www.zhitoujianli.com

# 2. 重新登录
python boss_local_agent.py

# 3. 查看详细日志
python boss_local_agent.py --log-level DEBUG
```

### 问题3: Playwright安装失败

**Windows**:
```cmd
pip install --upgrade playwright
playwright install chromium
```

**Mac/Linux**:
```bash
pip3 install --upgrade playwright
python3 -m playwright install chromium
playwright install-deps  # Linux需要
```

### 问题4: "需要登录Boss直聘"

**解决方法**:
1. 确保使用有头模式（不加 --headless）
2. 在打开的浏览器中完成扫码登录
3. 登录成功后Agent会自动继续

### 问题5: 内存占用过高

**解决方法**:
- 使用无头模式: `--headless`
- 定期重启Agent
- 关闭其他浏览器窗口

---

## 更新日志

### v2.0.0 (2025-12-22)
- **重大更新**: 移除Token机制，改用账号密码登录
- 支持保存登录信息，下次自动登录
- 简化操作流程，从3步减少到2步
- 改进错误提示信息

### v1.0.0 (2025-12-18)
- 首次发布
- 支持Boss直聘投递
- WebSocket实时通信
- 有头/无头模式
- 反检测技术

---

## 获取帮助

如果您遇到问题：

1. **查看本文档**的「故障排除」部分
2. **查看日志文件** `boss_agent.log`
3. **联系客服**获取支持

---

**智投简历团队** | 让求职更高效
